
const mongoose = require('mongoose');

const valueBetSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  match: String,
  odds: Number,
  expectedValue: Number
});

module.exports = mongoose.model('ValueBet', valueBetSchema);
