
const mongoose = require('mongoose');

const bankrollSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  amount: { type: Number, default: 0 }
});

module.exports = mongoose.model('Bankroll', bankrollSchema);
